# Following_Camera
Projet de caméra suiveuse (C + Arduino) avec openCV (Projet Licence 3)
